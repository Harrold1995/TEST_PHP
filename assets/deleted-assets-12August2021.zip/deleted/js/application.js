jQuery(function ($) {
	jQuery(window).on('load', function () {
		if (typeof wpDataCharts !== 'undefined') {
			for (var chart_id in wpDataCharts) {
				if (wpDataCharts[chart_id].engine == 'chartjs') {
					if (wpDataCharts[chart_id].engine == 'chartjs') {
					}
				}
			}
		}

		if (typeof wpDataChartsCallbacks == 'undefined') {
			wpDataChartsCallbacks = {};
		}
		wpDataChartsCallbacks[2] = function (obj) {
			obj.options.data.datasets[0].backgroundColor = [
				'#50B432',
				'#ED561B'
			];
			obj.options.data.datasets[0].borderColor = [
				'#50B432',
				'#ED561B'
			];
			obj.options.options.scales.xAxes[0].barThickness = 40;
		}
	});
	$(document.body).on('click', '.toggle-arrow', function () {
		$('.cls-dashboard-outer').toggleClass("cls-hide-sidebar");
	});
	$(document.body).on('click', '.wdt-display-chart', function () {
		var pos = $(this).data('position_id');
		$('.navParent').addClass('hidden');
		$('.navParent.chart-' + pos).removeClass('hidden');
	});
	$(document.body).on('click', '.toggle-sidebar', function () {
		$("body").toggleClass('expand-full');
	});
	$(".show-password, .hide-password").on('click', function () {
		var passwordId = $(this).parents('.password-outer:first').find('input').attr('id');
		if ($(this).hasClass('show-password')) {
			$("#" + passwordId).attr("type", "text");
			$(this).parent().find(".show-password").hide();
			$(this).parent().find(".hide-password").show();
		} else {
			$("#" + passwordId).attr("type", "password");
			$(this).parent().find(".hide-password").hide();
			$(this).parent().find(".show-password").show();
		}
	});

	$(document).on('keyup change paste', '[type=password]', function (e) {
		if ($('.confirm-password-showhide').length) {
			if (this.value) {
				$(this).parents('.password-outer').find('.confirm-password-showhide').show();
			} else {
				$(this).parents('.password-outer').find('.confirm-password-showhide').hide();
			}
		}
	});

	$("#frmLogin").validate({
		rules: {
			email: {
				required: true,
				email: true
			},
			password: {
				required: true,
				minlength: 5
			}
		},
		messages: {
			email: {
				required: "Please provide an email",
				email: "Please enter a valid email address"
			},
			password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long"
			},
		},
		errorElement: "em",
		errorPlacement: function ( error, element ) {

			// Add the `help-block` class to the error element
			error.addClass( "help-block text-danger" );

			// Add `has-feedback` class to the parent div.form-group
			// in order to add icons to inputs
			element.parents( ".col-sm-5" ).addClass( "has-feedback" );

			if ( element.prop( "type" ) === "checkbox" ) {
				error.insertAfter( element.parent( "label" ) );
			} else {
				error.insertAfter( element );
			}

			// Add the span element, if doesn't exists, and apply the icon classes to it.
			if ( !element.next( "span" )[ 0 ] ) {
				$( "<span class='glyphicon glyphicon-remove form-control-feedback'></span>" ).insertAfter( element );
			}
		}
	});

	$(".sidebar-toggle").click(function(){
		$("body").toggleClass("slideSidebar");
	});
});
