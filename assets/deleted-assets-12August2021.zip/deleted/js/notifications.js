// this file contains various JS functions used for data validations
// Additional functions should be added as required by multiple views/pages
//

/**
 * confirmDelete is a sitewide function for confirmation
 * when deleting objects.
 * @param {function} confirmAction
 */
function confirmDelete(confirmAction)
{
	Swal.fire({
		title: 'Confirm Delete',
		text: "Are you sure you want to delete item?",
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	}).then((result) => {
		if (result.value) {
			confirmAction();
		}
	})
}

/**
 * confirmDelete is a sitewide function for confirmation
 * when deleting objects.
 * @param {function} confirmAction
 */
function confirmAction(message, confirmAction) {
	Swal.fire({
		title: 'Please Confirm',
		text: message,
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#008000',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, do it!'
	}).then((result) => {
		if (result.value) {
			confirmAction();
		}
	})
}
