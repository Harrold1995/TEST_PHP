// this file contains various JS functions used for data validations
// Additional functions should be added as required by multiple views/pages
//
